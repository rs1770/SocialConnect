<?php
   session_start();

  include("classes/connect.php");
  include("classes/login.php");
  
  $password = "";
  $email = "";
 
 
  if($_SERVER['REQUEST_METHOD'] == 'POST')
  {
 
      $login = new Login();
      $result = $login->evaluate($_POST);
 
      if($result != "")
      {
 
       echo "<div style = 'text-align:center;font-size:12px;color:white;background-color:grey;'>";
       echo "<br>The following errors occurred:<br><br>";
       echo $result;
       echo "<div>";     
      }
      else
      {

       header("Location: profile.php");
       die;
       
      }
      
      $password = $_POST['password'];
      $email = $_POST['email'];
 
  }
 
 
?>
 
<html>
 
<head>
<title>SocialConnect | Log in</title>
</head>
 
<style>

#bar{
   height: 100px;
   background-color: rgb(59,89,152);
   color:  #d9dfeb;
   padding:  4px;
}
#signup_button{
   background-color: white;
   width:  70px;
   text-align: center;
   padding: 4px;
   border-radius: 4px;
   float: right;
}
#login_button{
   background-color: white;
   width:  70px;
   text-align: center;
   padding: 4px;
   border-radius: 4px;
   float: right;
}
#bar2{
   background-color: white;
   width:800px;
   margin:auto;
   margin-top: 50px;
   padding:  10px;
   padding-top: 50px;
   text-align: center;
   Font-weight: bold;
   background: transparent;
}
 
#text{

Height: 40px;
Width: 300px;
Border-radius: 4px;
Border:solid 1px #ccc;
Padding: 4px;
Font-size: 14px;
}
 
#button{
   width: 300px;
   height: 40px;
   border-radius: 4px;
   font-weight: bold;
   border: none;
   background-color: rgb(50,89,152);
   color: white;
}
#signup_button2{
   background-color: white;
   width:  200px;
   text-align: center;
   padding: 4px;
   border-radius: 4px;
   
}
#login_button2{
   background-color: white;
   width:  200px;
   text-align: center;
   padding: 4px;
   border-radius: 4px;
   
}

</style>
<div id="bar">
<div style="font-size: 40px;"><strong>SocialConnect</strong></div>
<div id= "signup_button"><A HREF="signup.php">Sign up </A></div>
</div>
 
<BODY style="font-family: tahoma;background-image:url(bgimage.jpg); background-repeat:REPEAT SETTINGS;">


<div id="bar2">
<h1>Welocome to SocialConnect! Find your true space.</h1>

   
</div>
  <div class="container">
      <h1>About SocialConnect</h1>
      <h2>As more and more people are forced to stay at home in self‐isolation to prevent the further flow of the pathogen at the societal level, everyone's Mental Health is at risk. Physical distancing due to the COVID‐19 outbreak can have drastic negative effects on the mental health this platform will provide you the mental health support you need by connecting you to likeminded people.</h2>
      <br>
      <div id= "signup_button2" ><h4>New User? <A HREF="signup.php">Sign up </A></h4></div>
      <br>
      <div id= "login_button2"><h4>Existing User? <A HREF="login.php">Sign in </A></h4></div>
      <br><br>
</div>


</div>
</body>
 
</html>