<?php
session_start();
//print_r($_SESSION);

include("classes/connect.php");
include("classes/login.php");
include("classes/user.php");

//check if user logged
if(isset($_SESSION['socialconnect_userid']) && is_numeric($_SESSION['socialconnect_userid']))
{
    $id= $_SESSION['socialconnect_userid'];
    $login = new Login();
    $result = $login->check_userlogin($id);

    if($result)
    {
        //retrive user data
        
        $user = new User();

        $userdata = $user->get_userdata($id);

        if(!$userdata)
        {
            header("Location: login.php");
            die;
        }
        
    }
    else
    {
        header("Location: login.php");
        die;
    }

}
else
{
    header("Location: login.php");
    die;
}
//print_r($userdata);
?>
<!DOCTYPE html>
   <html>
   <head>
       <title>SocialConnect | Admin</title>
   </head>
 
   <style type="text/css">
 
       #blue_bar{
 
           height: 50px;
           background-color: #405d9b;
           color: #d9dfeb;
      
       }
 
       #search_box{
 
           width: 400px;
           height: 20px;
           border-radius: 5px;
           border:none;
           padding: 4px;
           font-size: 14px;
           background
 
       }
 
       #profile_pic{
 
           width: 150px;
           margin-top: -200px;
           border-radius: 50%;
           border:solid 2px white;
       }
 
       #menu_buttons{
 
           width: 100px;
           background-color: black;
           display: inline;
       }
 
   </style>
 
 <body style="font-family: tahoma; background-color: #d0d8e4; background-image:url(bgimage.jpg)">
 
       <br>
       <!--top bar-->
       <div id="blue_bar">
           <div style="width: 800px;margin:auto;font-size: 30px;">
 
                SocialConnect Admin &nbsp <input type="text" id="search_box" placeholder="Search for people to connect and socialize in the pandemic crisis">
                <a href="logout.php" ><span style="font-size: 14px;float: right;margin:10px;color:white;">Logout</span></a>
                <img src="selfie.jpg" style="width: 50px;float: right;">
 
           </div>
       </div>
 
       <!--cover area-->
       <div style="width: 800px;margin:auto;background-color: black; min-height: 400px;">
 
           <div style="background-color: white;text-align: center;color: #405d9b">
 
               
               <br>
               Admin Page - Manage Users
               <br>
 
               
 
           </div>
 
       </div>
 
   </body>
</html>
