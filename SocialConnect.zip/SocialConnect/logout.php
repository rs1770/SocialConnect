<?php

session_start();

if(isset($_SESSION['socialconnect_userid']))
{
   $_SESSION['socialconnect_userid'] = NULL;
   unset($_SESSION['socialconnect_userid']);
}

 header("Location: login.php");
 die;
 
?>
 
