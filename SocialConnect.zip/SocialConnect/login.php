<?php
   session_start();
   //Roshan added
  include("classes/connect.php");
  //Abdul added
  include("classes/login.php");
  
  $password = "";
  $email = "";
 
 
  if($_SERVER['REQUEST_METHOD'] == 'POST')
  {
 
      $login = new Login();
      $result = $login->evaluate($_POST);
 
      if($result != "")
      {
 
       echo "<div style = 'text-align:center;font-size:16px;color:white;background-color:grey;'>";
       echo "<br>The following errors occurred:<br><br>";
       echo $result;
       echo "<div>";     
      }
      else
      {

       header("Location: profile.php");
       die;
       
      }
      
      $password = $_POST['password'];
      $email = $_POST['email'];
 
  }
 
 
?>
 
<html>
 
<head>
<title>SocialConnect | Log in</title>
</head>
 
<style>
 
#bar{
   height: 100px;
   background-color: rgb(59,89,152);
   color:  #d9dfeb;
   padding:  4px;
}
#signup_button{
   background-color: #42b72a;
   width:  70px;
   text-align: center;
   padding: 4px;
   border-radius: 4px;
   float: right;
}
#bar2{
   background-color: white;
   width:800px;
   margin:auto;
   margin-top: 50px;
   padding:  10px;
   padding-top: 50px;
   text-align: center;
   Font-weight: bold;
   background: transparent;
}
 
#text{
 
Height: 40px;
Width: 300px;
Border-radius: 4px;
Border:solid 1px #ccc;
Padding: 4px;
Font-size: 14px;
}
 
#button{
   width: 300px;
   height: 40px;
   border-radius: 4px;
   font-weight: bold;
   border: none;
   background-color: rgb(50,89,152);
   color: white;
}
 
</style>
<div id="bar">
<div style="font-size: 40px;"><strong>SocialConnect</strong></div>
<div id= "signup_button"><A HREF="signup.php">Sign up </A></div>
</div>
 
<BODY style="font-family: tahoma;background-image:url(bgimage.jpg); background-repeat:REPEAT SETTINGS;">;


<div id="bar2">
<h1>Welcome to SocialConnect! Find your true space.</h1>

   <form method="post" >
 
       <strong>Log in to SocialConnect</strong><br><br>
 
   <input value="<?php echo $email ?>" name="email" type="text" id="text" placeholder="Email address or phone number"><br><br>
   <input value="<?php echo $password ?>" name= "password"  type="password" id="text" placeholder="Password"><br><br>
 
   <input type="submit" id="button" value="Log In">
   <br><br><br>
   </form>
</div>
  
    
</BODY>
 
</html>
