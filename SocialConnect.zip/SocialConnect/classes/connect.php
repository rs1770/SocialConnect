<?php

class myclass
{

    public $name = "someone ";

    function one()
    {
        echo $this->name;
    }

    function two()
    {
        echo "two <br>";
    }
}

$a = new myclass();

echo $a->name;
