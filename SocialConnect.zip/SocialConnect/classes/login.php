<?php
//Abdul created the class
class Login
{

    private $error = "";
  
    public function evaluate($data)
   {
       
       $email = addslashes($data['email']);
       $password = addslashes($data['password']);
        //Roshan added code
       //to avoid sql attack check one by one
       $query = "select * from users where email= '$email' limit 1";
 
       $DB = new Database();
       $result = $DB->read($query);
       if($result)
       {
            $row = $result[0];
            if($password == $row['password'])
            {
                //create session data
                //userid is the location to save the session variable, anyvalue stores in session  is accesed across the session
                $_SESSION['socialconnect_userid'] = $row['userid'];
            }
            else
            {
                $this->error .= "invalid password<br>";
            }
       }
       else
        {
            $this->error .= "invalid email<br>";
        }
       return $this->error;
       
   }

   public function check_userlogin($id)
   {
    //Roshan added the query
    $query = "select * from users where userid = '$id' limit 1";
 
        $DB = new Database();
        $result = $DB->read($query);
        
        if($result)
        {
            return true;
        }
        return false;
   }

}