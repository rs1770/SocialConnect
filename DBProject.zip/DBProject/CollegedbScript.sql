-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema Collegedb
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema Collegedb
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `Collegedb` DEFAULT CHARACTER SET utf8 ;
USE `Collegedb` ;

-- -----------------------------------------------------
-- Table `Collegedb`.`College`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `Collegedb`.`College` (
  `College_id` INT NOT NULL AUTO_INCREMENT,
  `College_name` VARCHAR(100) NOT NULL,
  `College_address` VARCHAR(100) NOT NULL,
  `College_city` VARCHAR(45) NOT NULL,
  `College_state` VARCHAR(10) NOT NULL,
  `College_zip` VARCHAR(10) NOT NULL,
  PRIMARY KEY (`College_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `Collegedb`.`Department`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `Collegedb`.`Department` (
  `Department_id` INT NOT NULL,
  `Department_name` VARCHAR(50) NOT NULL,
  `College_College_id` INT NOT NULL,
  PRIMARY KEY (`Department_id`, `College_College_id`),
  INDEX `fk_Department_College_idx` (`College_College_id` ASC) VISIBLE,
  CONSTRAINT `fk_Department_College`
    FOREIGN KEY (`College_College_id`)
    REFERENCES `Collegedb`.`College` (`College_id`)
    ON DELETE CASCADE
    ON UPDATE CASCADE)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `Collegedb`.`Instructor`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `Collegedb`.`Instructor` (
  `Instructor_id` INT NOT NULL,
  `Instructor_name` VARCHAR(50) NOT NULL,
  `Instructor_email` VARCHAR(100) NOT NULL,
  `Instructor_phone` VARCHAR(15) NOT NULL,
  `Department_Department_id` INT NOT NULL,
  `Department_College_College_id` INT NOT NULL,
  PRIMARY KEY (`Instructor_id`, `Department_Department_id`, `Department_College_College_id`),
  INDEX `fk_Instructor_Department1_idx` (`Department_Department_id` ASC, `Department_College_College_id` ASC) VISIBLE,
  CONSTRAINT `fk_Instructor_Department1`
    FOREIGN KEY (`Department_Department_id` , `Department_College_College_id`)
    REFERENCES `Collegedb`.`Department` (`Department_id` , `College_College_id`)
    ON DELETE CASCADE
    ON UPDATE CASCADE)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `Collegedb`.`ODS`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `Collegedb`.`ODS` (
  `ODS_Directorid` INT NOT NULL,
  `ODS_Directorname` VARCHAR(15) NOT NULL,
  `ODS_Directoremail` VARCHAR(100) NOT NULL,
  `ODS_Directorphone` VARCHAR(15) NOT NULL,
  PRIMARY KEY (`ODS_Directorid`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `Collegedb`.`Academic_Advisor`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `Collegedb`.`Academic_Advisor` (
  `Advisor_id` INT NOT NULL,
  `Advisor_name` VARCHAR(15) NOT NULL,
  `Advisor_email` VARCHAR(100) NOT NULL,
  `Advisor_phone` VARCHAR(15) NOT NULL,
  PRIMARY KEY (`Advisor_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `Collegedb`.`Student`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `Collegedb`.`Student` (
  `Student_id` INT NOT NULL,
  `Student_fname` VARCHAR(15) NOT NULL,
  `Student_lname` VARCHAR(15) NOT NULL,
  `Student_email` VARCHAR(100) NOT NULL,
  `Student_phone` VARCHAR(15) NOT NULL,
  `Student_age` INT NOT NULL,
  `ODS_ODS_Directorid` INT NULL,
  `Academic_Advisor_Advisor_id` INT NULL,
  PRIMARY KEY (`Student_id`, `Student_age`),
  INDEX `fk_Student_ODS1_idx` (`ODS_ODS_Directorid` ASC) VISIBLE,
  INDEX `fk_Student_Academic_Advisor1_idx` (`Academic_Advisor_Advisor_id` ASC) VISIBLE,
  CONSTRAINT `fk_Student_ODS1`
    FOREIGN KEY (`ODS_ODS_Directorid`)
    REFERENCES `Collegedb`.`ODS` (`ODS_Directorid`)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
  CONSTRAINT `fk_Student_Academic_Advisor1`
    FOREIGN KEY (`Academic_Advisor_Advisor_id`)
    REFERENCES `Collegedb`.`Academic_Advisor` (`Advisor_id`)
    ON DELETE CASCADE
    ON UPDATE CASCADE)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `Collegedb`.`Course`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `Collegedb`.`Course` (
  `Course_id` INT NOT NULL,
  `Course_name` VARCHAR(15) NOT NULL,
  `Course_credits` INT NOT NULL,
  `Instructor_Instructor_id` INT NOT NULL,
  `Instructor_Department_Department_id` INT NOT NULL,
  `Instructor_Department_College_College_id` INT NOT NULL,
  `Department_Department_id` INT NOT NULL,
  `Department_College_College_id` INT NOT NULL,
  PRIMARY KEY (`Course_id`, `Course_credits`, `Instructor_Instructor_id`, `Instructor_Department_Department_id`, `Instructor_Department_College_College_id`, `Department_Department_id`, `Department_College_College_id`),
  INDEX `fk_Course_Instructor1_idx` (`Instructor_Instructor_id` ASC, `Instructor_Department_Department_id` ASC, `Instructor_Department_College_College_id` ASC) VISIBLE,
  INDEX `fk_Course_Department1_idx` (`Department_Department_id` ASC, `Department_College_College_id` ASC) VISIBLE,
  CONSTRAINT `fk_Course_Instructor1`
    FOREIGN KEY (`Instructor_Instructor_id` , `Instructor_Department_Department_id` , `Instructor_Department_College_College_id`)
    REFERENCES `Collegedb`.`Instructor` (`Instructor_id` , `Department_Department_id` , `Department_College_College_id`)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
  CONSTRAINT `fk_Course_Department1`
    FOREIGN KEY (`Department_Department_id` , `Department_College_College_id`)
    REFERENCES `Collegedb`.`Department` (`Department_id` , `College_College_id`)
    ON DELETE CASCADE
    ON UPDATE CASCADE)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `Collegedb`.`Student_Course`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `Collegedb`.`Student_Course` (
  `Course_Course_id` INT NOT NULL,
  `Student_Student_id` INT NOT NULL,
  PRIMARY KEY (`Course_Course_id`, `Student_Student_id`),
  INDEX `fk_Student_Course_Student1_idx` (`Student_Student_id` ASC) VISIBLE,
  CONSTRAINT `fk_Student_Course_Course1`
    FOREIGN KEY (`Course_Course_id`)
    REFERENCES `Collegedb`.`Course` (`Course_id`)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
  CONSTRAINT `fk_Student_Course_Student1`
    FOREIGN KEY (`Student_Student_id`)
    REFERENCES `Collegedb`.`Student` (`Student_id`)
    ON DELETE CASCADE
    ON UPDATE CASCADE)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `Collegedb`.`Parking`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `Collegedb`.`Parking` (
  `Parking_id` INT NOT NULL,
  `Parking_location` VARCHAR(100) NOT NULL,
  PRIMARY KEY (`Parking_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `Collegedb`.`Student_Parking`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `Collegedb`.`Student_Parking` (
  `Parking_Parking_id` INT NOT NULL,
  `Student_Student_id` INT NOT NULL,
  INDEX `fk_Student_Parking_Parking1_idx` (`Parking_Parking_id` ASC) VISIBLE,
  INDEX `fk_Student_Parking_Student1_idx` (`Student_Student_id` ASC) VISIBLE,
  CONSTRAINT `fk_Student_Parking_Parking1`
    FOREIGN KEY (`Parking_Parking_id`)
    REFERENCES `Collegedb`.`Parking` (`Parking_id`)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
  CONSTRAINT `fk_Student_Parking_Student1`
    FOREIGN KEY (`Student_Student_id`)
    REFERENCES `Collegedb`.`Student` (`Student_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;

#college data
INSERT INTO `collegedb`.`college`
(`College_id`,
`College_name`,
`College_address`,
`College_city`,
`College_state`,
`College_zip`)
VALUES
(1,
'Rutgers-Newark University',
'Test STreet',
'Newark',
'NJ',
'123456');

#department data
INSERT INTO `collegedb`.`department`
(`Department_id`,
`Department_name`,
`College_College_id`)
VALUES
(001,
'Computer Science',
1);

#instructor data
INSERT INTO `collegedb`.`instructor`
(`Instructor_id`,
`Instructor_name`,
`Instructor_email`,
`Instructor_phone`,
`Department_Department_id`,
`Department_College_College_id`)
VALUES
(22,
'Mr. Ross Osman',
'ross@gmail.com',
'223-5648-9999',
001,
1);

ALTER TABLE course MODIFY Course_name VARCHAR(100) ;
#course data
INSERT INTO `collegedb`.`course`
(`Course_id`,
`Course_name`,
`Course_credits`,
`Instructor_Instructor_id`,
`Instructor_Department_Department_id`,
`Instructor_Department_College_College_id`,
`Department_Department_id`,
`Department_College_College_id`)
VALUES
(3,
'Database Systems',
3,
22,
001,
1,
001,
1),
(4,
'Cloud Computing',
3,
22,
001,
1,
001,
1),
(5,
'Data Structures',
3,
22,
001,
1,
001,
1);

#student data
INSERT INTO `collegedb`.`student`
(`Student_id`,
`Student_fname`,
`Student_lname`,
`Student_email`,
`Student_phone`,
`Student_age`,
`ODS_ODS_Directorid`,
`Academic_Advisor_Advisor_id`)
VALUES
(101,
'Jon',
'Snow',
'jon@gmail.com',
'123-456-7890',
21,
NULL,
556);

INSERT INTO `collegedb`.`student`
(`Student_id`,
`Student_fname`,
`Student_lname`,
`Student_email`,
`Student_phone`,
`Student_age`,
`ODS_ODS_Directorid`,
`Academic_Advisor_Advisor_id`)
VALUES
(102,
'Joanne',
'Starr',
'joanne@gmail.com',
'111-444-7890',
20,
111,
556);
#advisor data
INSERT INTO `collegedb`.`academic_advisor`
(`Advisor_id`,
`Advisor_name`,
`Advisor_email`,
`Advisor_phone`)
VALUES
(556,
'Ms. Rose Mary',
'rose@gmail.com',
'223-455-7899');
#ods data
INSERT INTO `collegedb`.`ods`
(`ODS_Directorid`,
`ODS_Directorname`,
`ODS_Directoremail`,
`ODS_Directorphone`)
VALUES
(111,
'Andrew Ross',
'andrew@yahoo.com',
'555-888-9632');

INSERT INTO `collegedb`.`student_course`
(`Course_Course_id`,
`Student_Student_id`)
VALUES
(3,
101),
(4,
101),
(5,
101),
(3,
102),
(4,
102);

select * from student;

select * from academic_advisor;

select * from ods;

UPDATE student
 SET Student_email = 'johnson@gmail.com'
 WHERE Student_id = 101;
 
 DELETE FROM student
 WHERE Student_id = 102;
 
 SELECT COUNT(*) FROM student
 WHERE Student_age > 18 ;
 
 SELECT MAX(Student_age) FROM student ;
 
 SELECT S.Student_id, S.Student_fname, Student_lname, S.Student_email, C.Course_name, C.Course_credits
 FROM student AS S
 JOIN student_course as SC ON S.Student_id = SC.Student_Student_id
 JOIN course as C ON C.Course_id = SC.Course_Course_id;
 
 DESCRIBE course;
 SELECT * FROM Course;
 SELECT Course_credits, COUNT(*) FROM course
 GROUP BY Course_credits;
 
 SELECT Student_id, Student_fname, Student_lname, sum(Student_age) AS totalAges
 FROM student
 GROUP BY Student_id, Student_fname,Student_lname, Student_email
 HAVING Sum(Student_age >= 18) ;
 
 