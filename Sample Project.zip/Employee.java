
public class Employee {
	String empname;
	int empid;
	//Aggregation
    Car car;
    private int hour;
    //The static number
	private static final double payrate=0.3;
	Employee(String empname, int empid, Car car) {
	    this.empname = empname;
	    this.empid = empid;
	    this.car = car;
	  }
	// The static Method
	public static void info() {
		System.out.println("This is an employee");
	}
	public void setHour(int hour) {
		this.hour=hour;
	}
	public double Pay() {
		return payrate*hour;
	}
	
}
