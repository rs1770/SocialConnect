
public class Executive extends Employee{
    private int hour;
    //The two static numbers
	private static final double payrate=0.6;
	private static final double bonus=165.5;
	Executive(String empname, int empid, Car car) {
	    super(empname,empid,car);
	  }
	//The static method and overriding superclass Employee's info()
	public static void info() {
		System.out.println("This is an executive");
	}
	//mutator
	public void setHour(int hour) {
		this.hour=hour;
	}
	//Overriding superclass Employee's Pay() method
	public double Pay() {
		return payrate*hour+bonus;
	}
}
