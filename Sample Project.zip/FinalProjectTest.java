import java.util.*;
import java.io.*;
public class FinalProjectTest {
	//I select stack as array-based data structure
	static Stack<Double> payment = new Stack<>();
	// Use Recursion to print the Array
	public static void printArray(Double[] arr, int count) {
		if(count ==  -1) {
			return;
		}
		System.out.print(arr[count] + " ");
		printArray(arr, count - 1);
	}
	//Selection Sort
	public static void selectionSort(Double[] data) {
		 for(int i=0;i<data.length-1;i++) {
			  int smallest=i;
			  for(int index=i+1;index<data.length;index++) {
				  if(data[index]<data[smallest]) {
					  smallest=index;
				  }
			  }
			  swap(data,i,smallest);
		  }
	  }
	
	private static void swap(Double[] data,int first,int second) {
		  double temporary=data[first];
		  data[first]=data[second];
		  data[second]=temporary;
	  }
	//Insertion Sort
	public static void insertionSort(Double[] data) {
		  for(int next=1;next<data.length;next++) {
			  double insert=data[next];
			  int moveItem=next;
			  while(moveItem>0&&data[moveItem-1]>insert) {
				  data[moveItem]=data[moveItem-1];
				  moveItem--;
			  }
			  data[moveItem]=insert;
	
			  }
	  }
	//Binary Search
	public static int binarySearch(Double[]data,double key) {
		  int low=0;
		  int high=data.length-1;
		  int middle=(low+high+1)/2;
		  int location=-1;
		  do {if (key==data[middle]) {
				  location=middle;
			  }
			  else if(key<data[middle]) {
				  high=middle-1;
			  }
			  else {
				  low=middle+1;
			  }
			  middle=(low+high+1)/2;
		  }
		  while((low<=high)&&(location==-1));
		  return location;
	 }
	
	public static void main(String args[]) throws FileNotFoundException,IOException{//Exception Handling
	      //Input and read the File
		  Scanner input=new Scanner(new File("vehicle.txt"));
		  while(input.hasNextLine()) {
			  String wholeLine =input.nextLine();
			  String[] arr = wholeLine.split(" ");
		  if(arr[0].equals("Employee")) {
			  String empname= arr[1];
			  int empid=Integer.valueOf(arr[2]);
			  String make=arr[3];
			  String model=arr[4];
			  Long cost=Long.valueOf(arr[5]);
			  int years=Integer.valueOf(arr[6]);
			  Car car=new Car(make,model,cost,years);
			  //Aggregation: Employee has a Car.
			  Employee e=new Employee(empname,empid,car);
			  Employee.info();
			  System.out.println("No."+Car.count);
			  System.out.println("----------Employee Details:------------");
			  System.out.println("Employee Name: " + e.empname);
			  System.out.println("Employee ID: " + e.empid);
			  Scanner scan=new Scanner(System.in);
			  System.out.println("How long does this employee work per day : ");
			  int hour=scan.nextInt();
			  //Use the mutator from Employee Class
			  e.setHour(hour);
			  System.out.println("Employee payment: "+e.Pay());
			  payment.add(e.Pay());
			  System.out.println("----------Employee's car details-------");
			  //Use the accessor getMake();
			  System.out.println("Car Name: " + e.car.getMake()+" "+e.car.getModel());
			  System.out.println("Car Maintainence Fee: " + e.car.getCost());
			  System.out.println("Car used years: " + e.car.getYear());
			  System.out.println("Car Maintainence Cost per year: "+e.car.Ratio());
			  //Use overloading car.Ratio()
			  System.out.println("Car Maintainence Cost and other fees per year: "+e.car.Ratio(15000));
		    }
		 if(arr[0].equals("Executive")) {
			  String empname= arr[1];
			  int empid=Integer.valueOf(arr[2]);
			  String make=arr[3];
			  String model=arr[4];
			  Long cost=Long.valueOf(arr[5]);
			  int years=Integer.valueOf(arr[6]);
			  Car car=new Car(make,model,cost,years);
			  //Aggregation: Employee has a Car.
			  Employee e=new Executive(empname,empid,car);//Polymorphism: Employee is superclass and Executive is subclass
			  //static method in Executive, the method info() uses overriding
			  Executive.info();
			  System.out.println("No."+Car.count);
			  System.out.println("----------Employee Details:------------");
			  System.out.println("Employee Name: " + e.empname);
			  System.out.println("Employee ID: " + e.empid);
			  Scanner scan=new Scanner(System.in);
			  System.out.println("How long does this executive work per day : ");
			  int hour=scan.nextInt();
			  // use the mutator
			  e.setHour(hour);
			  System.out.println("Employee payment: "+e.Pay());
			  payment.add(e.Pay());
			  System.out.println("----------Employee's car details-------");
			  System.out.println("Car Name: " + e.car.getMake()+" "+e.car.getModel());
			  System.out.println("Car Maintainence Fee: " + e.car.getCost());
			  System.out.println("Car used years: " + e.car.getYear());
			  System.out.println("Car Maintainence Cost per year: "+e.car.Ratio());
			 //Use overloading method: Car.Ratio(20000)
			  System.out.println("Car Maintainence Cost and other fees per year: "+e.car.Ratio(20000));
			}
		 }
	  // Convert stack to array
	    int len = payment.size(), i  = 0;
		Double[] array = new Double[len];
		while(!payment.isEmpty()) {
			array[i++] = payment.pop();
		}	
		input.close();
		//Use Insertion Sort to sort the array
		insertionSort(array);
		printArray(array,array.length-1);
		System.out.println();
		//Use selection Sort to sort the array
		selectionSort(array);
		printArray(array, array.length - 1);
		System.out.println();
		//Use Binary Search to find the position of elements in Array sorted
		Scanner scan=new Scanner(System.in);
		System.out.println("Please enter an integer value(-1 to quit): ");
		double search=scan.nextDouble();
		while(search!=-1) {
			int location=binarySearch(array,search);
			if(location==-1) {
				System.out.printf("%f was not found %n%n", search);
			}
			else {
				System.out.printf("%f was found in position %d%n%n", search,array.length-location);
			}
			System.out.print("Please enter an integer value(-1 to quit): ");
			search=scan.nextDouble();
		}
		  }
	
	}
 




