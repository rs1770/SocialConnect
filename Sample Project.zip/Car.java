//Car class implements Vehicle interface
public class Car implements Vehicle{
	// One static number
	public static int count=0;
	private String make,model;
	private Long cost;
	private int year;
	public Car(String make,String model,Long cost,int year) {
	  this.make=make;
	  this.model=model;
	  this.cost=cost;
	  this.year=year;
	  count++;
	}
	// The static Method
	public static void info() {
		System.out.println("This is a car");
	}
	
	//Accessor
	public String getMake() {
		return make;
	}
	public String getModel() {
		return model;
	}
	public Long getCost() {
		return cost;
	}
	//Mutator
	public void setCost(long newcost) {
		cost=newcost;
	}
    public int getYear() {
    	return year;
    }
    //Overloading
    public double Ratio() {
    	double ratio=cost/year;
    	return ratio;
    }
    public double Ratio(double fee) {
    	double ratio=(fee+cost)/year;
    	return ratio;
    }
}
