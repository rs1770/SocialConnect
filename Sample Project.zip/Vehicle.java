//This is the interface
public interface Vehicle {
	//These are abstract methods of Vehicle interface
	public  String getMake();
	public  String getModel();
	public  Long getCost();
	public  void setCost(long newcost);
	public  int getYear();
	public  double Ratio();
}
